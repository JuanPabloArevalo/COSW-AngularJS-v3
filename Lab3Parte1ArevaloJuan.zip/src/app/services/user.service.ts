import {Injectable} from '@angular/core';

import {User} from '../models/user';

@Injectable()
export class UserService {

private users: User[] = [
    new User('Juan', 'Arevalo','https://media-exp2.licdn.com/mpr/mpr/shrinknp_200_200/AAEAAQAAAAAAAAzxAAAAJGRmY2Y1ZDMwLWE5OGQtNGY0NC05Y2Y0LTVkMGE4YzFlZTE1Ng.jpg'),
  ];

  constructor() {

  }

  list(): User[] {
    return this.users;
  }

  create(name: string, lastname: string, image: string) {
    this.users.push(new User(name, lastname, image));
  }
}
